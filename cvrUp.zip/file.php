<?php

$usrnm=$_POST['username'];
$pass=$_POST['password'];

if (($usrnm == 'cvr') && ($pass == 'smartbins')){
header("Location:index.php");}
else{
header("Location:index.html");
}




?>

