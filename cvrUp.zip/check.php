<?php

$usrnm=$_GET['username'];
$pass=$_GET['password'];


?>
<html>

	<head>
		<title>E-Bins Monitor</title>
	</head>

	<body>


		<p>echo $usrnm;</p>
		<p>echo $pass;</p>
	</body>

</html>
