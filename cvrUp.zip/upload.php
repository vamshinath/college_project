<?php
$username = "vamshi_writer";
$password = "team1";
$hostname = "apple.heliohost.org:3306/"; 

date_default_timezone_set('Asia/Calcutta');
$CurrDate=date('Y-m-d H:i:s');
$day=substr(date("l"),0,3);
$dt=date('d');

$CurrPer = htmlentities($_GET['percentage']);
$id = htmlentities($_GET['id']);

$myfile = fopen($id.".txt","w");
fwrite($myfile,$CurrPer."\n");
fwrite($myfile,$CurrDate);
fclose($myfile);
sleep(2);
echo "Connection Successful</br>";
echo "successfully updated";



?>
